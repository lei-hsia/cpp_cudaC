#### pass-by-reference, pass-by-pointer

https://www.geeksforgeeks.org/passing-by-pointer-vs-passing-by-reference-in-c/

相同点: swap a,b, 两者都swap了called function外原来的calling function中的a, b

<b>Difference in Reference variable and pointer variable</b>:

References are generally implemented using pointers. A reference is same object, just with a different name and reference must refer to an object. Since references can’t be NULL, they are safer to use.

- A pointer can be re-assigned while reference cannot, and must be assigned at initialization only.

- Pointer can be assigned NULL directly, whereas reference cannot.

- Pointers can iterate over an array, we can use ++ to go to the next item that a pointer is pointing to.

- <b>A pointer is a variable that holds a memory address. A reference has the same memory address as the item it references.</b>

- A pointer to a class/struct uses ‘->'(arrow operator) to access it’s members whereas a reference uses a ‘.'(dot operator)

- A pointer needs to be dereferenced with * to access the memory location it points to, whereas a reference can be used directly.

