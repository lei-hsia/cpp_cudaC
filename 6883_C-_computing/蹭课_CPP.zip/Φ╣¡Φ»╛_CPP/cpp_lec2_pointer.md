```
(should have a #)define Options01_h

int GetInputData(int& N, double& N)

int GetInputData(double &S0, double &r, double R):
 
```
1. same function name, same return type, different arguments: overloading

2. &: call by reference: when change the value, also change the original value

```
double price[N+1]
```
price: array of size N+1
element type: double

1. MS visual studio
2. Mac Xcode

```
int price[N+1]; // def an array of size (N+1)

// outOfBound, but can do it, nothing following
for(int i=0;i<=N+1;i++)
	cout << price[i];  
	
// ACHTUNG: changed memory, if someone else 
// use it, program crashes.
for(int i=0;i<=N+1;i++)
	price[i]+= 1.0;
```
3. CPP array is LIGHT-WIEGHT, i.e. has NO BOUNDARY CHECK.

4. Big-O for array: O(1): get value by index: a[100]/a[1000000] is the same

5. main: acts as only the CALLER function; and write all functionalities in other files:
	a. logic separation: caller & methods
	b. physical sepa: different files

####chap2: pointer

1.
```
int a =1;
cout << &a; // address(a)
```
int *intptr = &a;
&:
	1) call-by-reference; 
	2) address operator
	