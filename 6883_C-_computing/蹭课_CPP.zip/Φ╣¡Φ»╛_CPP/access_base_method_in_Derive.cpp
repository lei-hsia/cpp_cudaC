#include <iostream>
using namespace std;

// access functions of BaseClass inside Derived Class
class Point{
protected:
	int x, y;
public:
	void set(int a, int b){
		x=a; y=b;
	}
	void foo();
	void print(){
		cout << "print in Point class" << endl;
	}
}

class Circle : class Point{
private: 
	double r;
public:
	void set(int a,int b,double c){
		Point::set(a, b);  // same name func call
		r = c;
	}
	void print();
	void Point::print();
}

int main(){

	Point A;
	A.set(30, 50);  // from base class Point
	A.print();  // from base class Point

	Circle C;
	C.set(10, 10, 100);  // from class Circle
	C.foo();  // from base class Point
	C.print();  // from class Circle
	C.Point::print();

	return 0;

}