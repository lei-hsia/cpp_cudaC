1. ```static``` members belong to the class instead of a specific instance

2. ```static``` methods do not belong to a specific instance, they CANNOT refer to instance members: <b>hence, ```public static void main``` cannot call non-static methods directly: must create an object/reference, then call the method on the object</b>. 就是在public static void main这个main函数中，因为是static所以call一个nonstatic方法的时候必须定义一个object然后call method on the object, 不能直接call object; 而如果是static method就可以直接call

##### static members can only refer to static members
##### static members can access instance members through an object reference.
##### instance members can access static members

```
public class Example{
	private static boolean staticField;
	private boolean instanceField;
	public static void main(String[] args){
		// a static method can access static fields
		staticField = true;
		
		// a static method can access instance fields through an object reference
		Example instance = new Example();
		instance.instanceField = true;
```